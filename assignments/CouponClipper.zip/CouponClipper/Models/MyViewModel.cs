    public class MyViewModel
    {
        public User User { get; set; }
        public int CouponsUsedCount { get; set; }
        public int MyUsedCoupons { get; set; }
    }
